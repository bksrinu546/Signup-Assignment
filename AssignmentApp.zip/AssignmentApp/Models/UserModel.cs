﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using AssignmentApp.Attributes;

namespace AssignmentApp.Models
{
    public class UserModel
    {
        [Required(ErrorMessage = "Please Enter name")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Please Enter Username")]
        public string Username { get; set; }
        [Required(ErrorMessage = "Please Enter password")]
        public string Password { get; set; }
        [Required(ErrorMessage = "Please Enter confirm password")]
        [Compare("Password", ErrorMessage = "Confirm Password doesn't match")]
        public string ConfirmPassword { get; set; }
        [RegularExpression("^[6,7,8,9]\\d{9}$", ErrorMessage = "Please Enter Correct Contact No.")]
        public string Contact { get; set; }
        [Required(ErrorMessage = "Please Enter Country")]
        [Display(Name="Country")]
        public Country Country { get; set; }

        [Display(Name = "City")]
        public City City { get; set; }
        [Required(ErrorMessage = "Please Select Gender")]
        public string Gender { get; set; }
        [ValidateCheckbox(ErrorMessage = "Please Accept Terms")]
        public bool Terms { get; set; }
    }
    public class Country
    {
        [ValidateDropDown(ErrorMessage = "Please Select Country")]
        public int? ID { get; set; }
        public string Name { get; set; }
    }
    public class City
    {
        [ValidateDropDown(ErrorMessage = "Please Select City")]
        public int ID { get; set; }
        public string Name { get; set; }
        public int Country { get; set; }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Mvc.ModelBinding.Validation;
using System.Collections;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.AspNetCore.Mvc;

namespace AssignmentApp.Attributes
{
    public class ValidateDropDown : ValidationAttribute, IClientModelValidator
    {
        public void AddValidation(ClientModelValidationContext context)
        {
            context.Attributes.Add("data-val-dropdown", ErrorMessage);
        }

        public override bool IsValid(object value)
        {          

            if (value != null)
            {
                if (value.ToString() == "0")
                    return false;               
                else
                    return true;
            }
            else return false;

        }
        //public IEnumerable GetClientValidationRules(ModelMetadata metadata, ControllerContext context)
        //{
        //    //return new ModelClientValidationRule
        //    //{
        //    //new ModelClientValidationRule { ValidationType = "dropdown", ErrorMessage = this.ErrorMessage } };

        //}
}
}

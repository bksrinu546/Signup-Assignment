﻿using AssignmentApp.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;

namespace AssignmentApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        public List<City> lstCities = new List<City>()
        {
            new City() { ID = 1, Name = "Hyderabad", Country = 2 },
            new City() { ID = 2, Name = "Bangalore", Country = 2 },
            new City() { ID = 3, Name = "Chicago", Country = 1 },
            new City() { ID = 4, Name = "NewYork", Country = 1 },

        };


        public List<Country> lstCountires = new List<Country>()
        {
                        new Country() { ID = 1, Name = "USA" },
            new Country() {  ID = 2, Name = "India" }


        };
        public HomeController(ILogger<HomeController> logger)
        {
            _logger = logger;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }
        public IActionResult SignUp()
        {
           
            ViewBag.Country = new SelectList(lstCountires, "ID", "Name"); 
            //ViewBag.City = lstCities;
            return View();
        }
        [HttpPost]
        public IActionResult SignUp(UserModel user)
        {
            
            if (ModelState.IsValid)
            {
                return RedirectToAction("Index", "Home");
            }
            ViewBag.Country = new SelectList(lstCountires, "ID", "Name");
            return View();
        }
        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public JsonResult GetCityList(int CountryId)
        {

            List<City> lstCity = lstCities.FindAll(x => x.Country == CountryId);
            return new Microsoft.AspNetCore.Mvc.JsonResult(lstCity);

        }
    }
}
